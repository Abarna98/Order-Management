package org.order.management.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@Getter
@Setter
public class Customer implements Serializable {


    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private int custId;

    @JsonProperty
    private List<Order> ordersList=new ArrayList<>();

    @JsonProperty
    private double totalPurchasedAmount;
}
