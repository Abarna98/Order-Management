package org.order.management.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Setter
@Getter
@Data
public class ProductDetailsUpdate implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private int productId;

    @JsonProperty
    private String productName;

    @JsonProperty
    private int price;

    @JsonProperty
    private int inStock;

}
