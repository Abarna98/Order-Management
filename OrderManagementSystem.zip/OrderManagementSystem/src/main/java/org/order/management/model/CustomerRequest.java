package org.order.management.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;


@Setter
@Getter
@Data
public class CustomerRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private String name;

    @JsonProperty
    private String address;

    @JsonProperty
    private String phoneNumber;

}
