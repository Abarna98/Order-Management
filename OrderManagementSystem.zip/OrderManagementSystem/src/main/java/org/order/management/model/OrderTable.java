package org.order.management.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Data
@Getter
@Setter
public class OrderTable implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private int orderId;

    @JsonProperty
    private int supId;

    @JsonProperty
    private String orderDate;

    @JsonProperty
    private String orderStatus;

    @JsonProperty
    private double totalPrice;

}
