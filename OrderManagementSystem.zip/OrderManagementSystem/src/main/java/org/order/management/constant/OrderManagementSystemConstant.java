package org.order.management.constant;

import org.springframework.stereotype.Component;

@Component
public class OrderManagementSystemConstant {

    public static final String DB_URL = "jdbc:mysql://localhost:3306/ordermanagement";

    public static final String USER_NAME="root";

    public static final String PASSWORD="";

    public static final String CUST_ID="CUST_ID";

    public static final String SUP_ID="SUP_ID";

    public static final String ORDER_ID="ORDER_ID";

    public static final String PROD_ID="PROD_ID";

    public static final String PROD_NAME="PROD_NAME";

    public static final String CUST_SUCCESS_RESPONSE="Successfully created customer details";

    public static final String SUP_SUCCESS_RESPONSE= "Successfully created supplier details";

    public static final String DATE_FORMAT= "yyyy-MM-dd";

    public static final String STOCK_INSERT_RESPONSE=" Successfully added stock details";

    public static final String STOCK_UPDATE_RESPONSE=" Successfully updated stock details";

    public static final String PENDING="PENDING";

    public static final String APPROVED="APPROVED";

    public static final String REJECTED="REJECTED";

    public static final String CANCELLED="CANCELLED";

    public static final String FAILED="FAILED";

    public static final String DELETED="DELETED";

    public static final String ORDER_APPROVED="Order Approved";

    public static final String ORDER_REJECTED ="Order Rejected";

    public static final String FAILED_TO_CANCEL="FAILED TO CANCEL;";

    public static final String ADMIN="admin";

    public static final String ORDER_STATUS="ORDER_STATUS";

    public static final String STATUS="STATUS";

    public static final String ORDERID_SPACE="OrderId ";

    public static final String CUSTID_SPACE="Customer Id ";

    public static final String HAS_BEEN_REMOVED=" has been removed";

    public static final String HAS_BEEN_FAILED=" has been failed to cancel";

    public static final String ALREADY_CANCELLED="Order has been already cancelled";

    public static final String ALREADY_APPROVED="Order has been already approved";

    public static final String ALREADY_REJECTED="Order has been already rejected";

    public static final String ALREADY_INACTIVE="Customer is already inactive";

    public static final int CONSTANT_ZERO=0;

    public static final int CONSTANT_ONE=1;

    public static final int CONSTANT_FOUR_HUNDRED=400;

    public static final double CONSTANT_POINT_3=0.03;

    public static final String ACTIVE="ACTIVE";

    public static final String IN_ACTIVE="IN ACTIVE";

    public static final String CUST_PHONE_NUMBER = "CUST_PHONE_NUMBER";

    public static final String GST_NO = "GST_NO";

    public static final String HAS_BEEN_CANCELLED = " Has been Cancelled";

    public static final String SUPPLIER_ALREADY_EXISTS = "Supplier already exists";

    public static final String SUPPLIER_DOESNOT_EXISTS = "Supplier doesn't exists";

    public static final String PRODUCT_DOESNOT_EXISTS = "Product doesn't exists";

    public static final String CUSTOMER_ALREADY_EXISTS = "Customer already exists";

    public static final String ORDER_ID_DOESNOT_EXISTS = "Order ID doesn't exists";

    public static final String CUSTOMER_ID_DOESNOT_EXISTS = "Customer ID doesn't exists";

    public static final String ORDER_CANNOT_BE_CANCELLED_NOW = "Order can not be cancelled now";

    public static final String ORDER_CANNOT_BE_UPDATED_NOW = "Order can not be updated now";
}
