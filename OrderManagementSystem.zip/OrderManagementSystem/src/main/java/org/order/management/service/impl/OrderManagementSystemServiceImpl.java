package org.order.management.service.impl;

import jakarta.annotation.Resource;
import org.order.management.client.OrderManagementSystemClient;
import org.order.management.constant.OrderManagementSystemConstant;
import org.order.management.model.*;
import org.order.management.utility.CustomException;
import org.order.management.utility.OrderManagementUtility;
import org.order.management.utility.ValidationUtility;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class OrderManagementSystemServiceImpl implements OrderManagementSystemService {

    @Resource
    ValidationUtility validationUtility;

    @Resource
    OrderManagementUtility orderManagementUtility;

    @Resource
    OrderManagementSystemClient orderManagementSystemClient;
    private OrderTable orderTable;

    @Override
    public ResponseEntity<CustomerResponse> getCustomerDetails(CustomerRequest customerRequest) throws Exception {
        CustomerResponse customerResponse = new CustomerResponse();
        //validates customer details from input
        validationUtility.validateCustomerInput(customerRequest, customerResponse);
        //checks whether customer exits or not
        if (orderManagementSystemClient.checkCustomerExist(customerRequest) == OrderManagementSystemConstant.CONSTANT_ZERO) {
            //if customer details is inserted, then response is returned
            if (orderManagementSystemClient.setCustomerDetails(customerRequest) == OrderManagementSystemConstant.CONSTANT_ONE) {
                int customerId = orderManagementSystemClient.getCustomerId();
                //sets response with customer id
                orderManagementUtility.setCustomerResponse(customerId, customerResponse);
            }
        } else {
            //throws error if customer already exits
            throw new CustomException(OrderManagementSystemConstant.CUSTOMER_ALREADY_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        return new ResponseEntity<>(customerResponse, HttpStatus.OK);
    }


    @Override
    public ResponseEntity<SupplierResponse> getSupplierDetails(Supplier supplier) throws Exception {
        SupplierResponse supplierResponse = new SupplierResponse();
        //validated supplier details from input
        validationUtility.validateSupplierInput(supplier, supplierResponse);
        //checks whether supplier exits or not
        if (orderManagementSystemClient.checkSupplierExist(supplier) == OrderManagementSystemConstant.CONSTANT_ZERO) {
            //if supplier details is inserted, then response is returned
            if (orderManagementSystemClient.setSupplierDetails(supplier) == OrderManagementSystemConstant.CONSTANT_ONE) {
                int supplierId = orderManagementSystemClient.getSupplierId();
                //sets response with customer id
                orderManagementUtility.getSupplierResponse(supplierId, supplierResponse);
            }
        } else {
            //throws error if supplier already exits
            throw new CustomException(OrderManagementSystemConstant.SUPPLIER_ALREADY_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        return new ResponseEntity<>(supplierResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<StockResponse> insertStockDetails(InsertStock insertStock) throws Exception {
        StockResponse stockResponse = new StockResponse();
        //validates stock details
        validationUtility.validateInsertStockInput(insertStock);
        List<String> productIds = new ArrayList<>();
        //check supplier exists or not
        if (orderManagementSystemClient.checkSupplierIdExist(insertStock.getSupplierId()) != OrderManagementSystemConstant.CONSTANT_ZERO) {
            for (ProductDetails productDetails : insertStock.getProductDetailsList()) {
                //inserts each product
                if (orderManagementSystemClient.insertStockDetails(productDetails, insertStock) == OrderManagementSystemConstant.CONSTANT_ONE) {
                    //gets inserted products details
                    String product = orderManagementSystemClient.getProduct();
                    productIds.add(product);
                }
            }
        } else {
            throw new CustomException(OrderManagementSystemConstant.SUPPLIER_DOESNOT_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        //set response for the inserted product
        orderManagementUtility.setStockResponse(productIds, stockResponse, OrderManagementSystemConstant.STOCK_INSERT_RESPONSE);
        return new ResponseEntity<>(stockResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<StockResponse> updateStockDetails(UpdateStock updateStock) throws Exception {
        StockResponse stockResponse = new StockResponse();
        //validates stock details
        validationUtility.validateUpdateStockInput(updateStock);
        List<String> productIds = new ArrayList<>();
        //check supplier exists or not
        if (orderManagementSystemClient.checkSupplierIdExist(updateStock.getSupplierId()) != OrderManagementSystemConstant.CONSTANT_ZERO) {
            for (ProductDetailsUpdate productDetails : updateStock.getProductDetailsList()) {
                //check product exist or not
                if (orderManagementSystemClient.checkProductExist(productDetails, updateStock.getSupplierId()) == OrderManagementSystemConstant.CONSTANT_ONE) {
                    //updated only if product exists
                    if (orderManagementSystemClient.updateStockDetails(productDetails, updateStock) == OrderManagementSystemConstant.CONSTANT_ONE) {
                        String product = String.valueOf(productDetails.getProductId()) + " : " + productDetails.getProductName();
                        productIds.add(product);
                    }
                } else {
                    throw new CustomException(OrderManagementSystemConstant.PRODUCT_DOESNOT_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
                }
            }
        } else {
            throw new CustomException(OrderManagementSystemConstant.SUPPLIER_DOESNOT_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        //set response for the updated product
        orderManagementUtility.setStockResponse(productIds, stockResponse, OrderManagementSystemConstant.STOCK_UPDATE_RESPONSE);
        return new ResponseEntity<>(stockResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<OrderResponse> getOrderDetails(OrderRequest orderRequest) throws Exception {
        OrderResponse orderResponse = new OrderResponse();
        //validate order inputs
        validationUtility.validateOrderInput(orderRequest);
        HashMap<Integer, Integer> mapPrice = new HashMap<Integer, Integer>();
        List<OrderResponseItem> orderResponseItemList = new ArrayList<>();
        double totalPrice = 0.0;
        //gets current price only if stock exist and mapped with productId
        for (OrderRequestItem orderRequestItem : orderRequest.getOrderRequestItemList()) {
            mapPrice.put(orderRequestItem.getProdId(), orderManagementSystemClient.getProductPrice(orderRequest.getSupId(), orderRequestItem.getProdId(), orderRequestItem.getQuantity()));
        }
        //generates order id by inserting order details
        if (orderManagementSystemClient.generateOrderId(orderRequest) == OrderManagementSystemConstant.CONSTANT_ONE) {
            int orderId = orderManagementSystemClient.getSingleOrderId();
            //sets order response
            orderResponse.setOrderId(orderId);
            orderResponse.setOrderDate(orderManagementUtility.getCurrentDate());
            for (OrderRequestItem orderRequestItem : orderRequest.getOrderRequestItemList()) {
                int orderItem = orderManagementSystemClient.insertOrderItems(orderId, orderRequestItem, mapPrice, orderRequest.getSupId());
                if (orderItem == OrderManagementSystemConstant.CONSTANT_ONE) {
                    OrderResponseItem orderResponseItem = orderManagementUtility.setResponseItem(orderRequestItem, mapPrice, orderResponse);
                    orderResponseItemList.add(orderResponseItem);
                }
            }
            orderResponse.setOrderResponseItemList(orderResponseItemList);
            for (OrderResponseItem orderResponseItem : orderResponseItemList) {
                totalPrice = totalPrice + orderResponseItem.getTotalPrice();
            }
            orderResponse.setSubTotal(totalPrice);
            orderResponse.setTaxAmount(totalPrice * OrderManagementSystemConstant.CONSTANT_POINT_3);
            orderResponse.setTotal(orderResponse.getSubTotal() + orderResponse.getTaxAmount());
            //inserting total price value in ORDER_DETAILS table
            orderManagementSystemClient.insertTotalPrice(orderResponse, orderId);

        }
        return new ResponseEntity<>(orderResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Messages> cancelOrder(int orderId) throws Exception {
        Messages messages = new Messages();
        if (orderManagementSystemClient.checkOrderIdExist(orderId) != OrderManagementSystemConstant.CONSTANT_ZERO) {
            //fetching the status of the order
            String orderStatus = orderManagementSystemClient.fetchOrderStatus(orderId);
            //check whether status is pending (only pending status can be cancelled)
            if (orderStatus.equals(OrderManagementSystemConstant.PENDING)||orderStatus.equals(OrderManagementSystemConstant.APPROVED)) {
                //update the status in ORDER_DETAILS table as cancel
                int orderDetails = orderManagementSystemClient.updateCancelStatus(orderId);
                //update the status in item records in ORDER_ITEMS table
                int orderItems = orderManagementSystemClient.cancelOrder(orderId);
                // update quantity status
                Map<Integer, Integer> item_quantity = orderManagementSystemClient.getQuantity(orderId);
                for (Integer prodId : item_quantity.keySet()) {
                    orderManagementSystemClient.updateStockQuantityForCancel(prodId, item_quantity);
                }
                //sets the response
                if (orderDetails != OrderManagementSystemConstant.CONSTANT_ZERO && orderItems != OrderManagementSystemConstant.CONSTANT_ZERO) {
                    messages.setStatus(OrderManagementSystemConstant.CANCELLED);
                    messages.setMessage(OrderManagementSystemConstant.ORDERID_SPACE + orderId + OrderManagementSystemConstant.HAS_BEEN_CANCELLED);
                } else {
                    messages.setStatus(OrderManagementSystemConstant.FAILED_TO_CANCEL);
                    messages.setMessage(OrderManagementSystemConstant.ORDERID_SPACE + orderId + OrderManagementSystemConstant.HAS_BEEN_FAILED);
                }
            } else if (orderStatus.equals(OrderManagementSystemConstant.CANCELLED)) {
                messages.setStatus(OrderManagementSystemConstant.FAILED_TO_CANCEL);
                messages.setMessage(OrderManagementSystemConstant.ALREADY_CANCELLED);
            }
        } else {
            throw new CustomException(OrderManagementSystemConstant.ORDER_ID_DOESNOT_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        return new ResponseEntity<>(messages, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Messages> removeCustomerDetails(int custId) throws Exception {
        Messages messages = new Messages();
        if (orderManagementSystemClient.checkCustomerIdExist(custId) != OrderManagementSystemConstant.CONSTANT_ZERO) {
            //fetching the status of the customer
            String custStatus = orderManagementSystemClient.fetchCustomerStatus(custId);
            //check whether customer is ACTIVE
            if (custStatus.equals(OrderManagementSystemConstant.ACTIVE)) {
                //update the status in CUSTOMER_DETAILS table as cancel
                int custDetail = orderManagementSystemClient.updateCustDetail(custId);

                //sets the response
                if (custDetail != OrderManagementSystemConstant.CONSTANT_ZERO) {
                    messages.setStatus(OrderManagementSystemConstant.DELETED);
                    messages.setMessage(OrderManagementSystemConstant.CUSTID_SPACE + custId + OrderManagementSystemConstant.HAS_BEEN_REMOVED);
                } else {
                    messages.setStatus(OrderManagementSystemConstant.FAILED_TO_CANCEL);
                    messages.setMessage(OrderManagementSystemConstant.CUSTID_SPACE + custId + OrderManagementSystemConstant.HAS_BEEN_FAILED);
                }
            } else if (custStatus.equals(OrderManagementSystemConstant.IN_ACTIVE)) {
                messages.setStatus(OrderManagementSystemConstant.FAILED_TO_CANCEL);
                messages.setMessage(OrderManagementSystemConstant.ALREADY_INACTIVE);
            }
        } else {
            throw new CustomException(OrderManagementSystemConstant.CUSTOMER_ALREADY_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        return new ResponseEntity<>(messages, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Messages> removeSupplierDetails(int supId) throws Exception {
        Messages messages = new Messages();
        if (orderManagementSystemClient.checkSupplierIdExist(supId) != OrderManagementSystemConstant.CONSTANT_ZERO) {
            //fetching the status of the supplier
            String supStatus = orderManagementSystemClient.fetchSupplierStatus(supId);
            //check whether supplier is ACTIVE
            if (supStatus.equals(OrderManagementSystemConstant.ACTIVE)) {
                //update the status in SUPPLIER_DETAILS table as cancel
                int supDetail = orderManagementSystemClient.updateSupDetail(supId);

                //sets the response
                if (supDetail != OrderManagementSystemConstant.CONSTANT_ZERO) {
                    messages.setStatus(OrderManagementSystemConstant.DELETED);
                    messages.setMessage(OrderManagementSystemConstant.CUSTID_SPACE + supId + OrderManagementSystemConstant.HAS_BEEN_REMOVED);
                } else {
                    messages.setStatus(OrderManagementSystemConstant.FAILED_TO_CANCEL);
                    messages.setMessage(OrderManagementSystemConstant.CUSTID_SPACE + supId + OrderManagementSystemConstant.HAS_BEEN_FAILED);
                }
            } else if (supStatus.equals(OrderManagementSystemConstant.IN_ACTIVE)) {
                messages.setStatus(OrderManagementSystemConstant.FAILED_TO_CANCEL);
                messages.setMessage(OrderManagementSystemConstant.ALREADY_INACTIVE);
            }
        } else {
            throw new CustomException(OrderManagementSystemConstant.SUPPLIER_DOESNOT_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        return new ResponseEntity<>(messages, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<CustomerReport> getCustomerReport(int custId) throws Exception {
        CustomerReport customerReport = new CustomerReport();
        if (orderManagementSystemClient.checkCustomerIdExist(custId) != OrderManagementSystemConstant.CONSTANT_ZERO) {
            customerReport.setCustId(custId);
            customerReport.setPhoneNumber(orderManagementSystemClient.getPhoneNumber(custId));
            List<OrderTable> orderTableList = orderManagementSystemClient.getOrderDetailsForCustReport(custId);
            customerReport.setTotalNoOfOrders(orderTableList.size());
            customerReport.setCompletedOrders(orderTableList.stream().filter(order -> order.getOrderStatus().equalsIgnoreCase("COMPLETED")).toList().size());
            customerReport.setPendingOrders(orderTableList.stream().filter(order -> order.getOrderStatus().equalsIgnoreCase("PENDING")).toList().size());
            customerReport.setCancelledOrders(orderTableList.stream().filter(order -> order.getOrderStatus().equalsIgnoreCase("CANCELLED")).toList().size());
            customerReport.setApprovedOrders(orderTableList.stream().filter(order -> order.getOrderStatus().equalsIgnoreCase("APPROVED")).toList().size());
            customerReport.setTotalPurchasedAmount(orderTableList.stream().mapToDouble(OrderTable::getTotalPrice).sum());
            List<Order> orderList = new ArrayList<>();
            for (OrderTable orderTable : orderTableList) {
                Order order = new Order();
                order.setOrderId(orderTable.getOrderId());
                order.setSupId(orderTable.getSupId());
                order.setOrderResponseItems(orderManagementSystemClient.getOrderItemDetails(orderTable.getOrderId()));
                order.setDate(orderTable.getOrderDate());
                order.setTotalPrice(orderTable.getTotalPrice());
                order.setStatus(orderTable.getOrderStatus());
                orderList.add(order);
            }
            customerReport.setOrdersList(orderList);
        } else {
            throw new CustomException(OrderManagementSystemConstant.CUSTOMER_ID_DOESNOT_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        return new ResponseEntity<>(customerReport, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SupplierReport> getSupplierReport(int supId) throws Exception {
        SupplierReport supplierReport = new SupplierReport();
        if (orderManagementSystemClient.checkSupplierIdExist(supId) != OrderManagementSystemConstant.CONSTANT_ZERO) {
            supplierReport.setSupId(supId);
            supplierReport.setGst(orderManagementSystemClient.getGSTNumber(supId));
            supplierReport.setProductList(orderManagementSystemClient.getProductDetails(supId, orderManagementSystemClient.getProdId(supId)));
            List<OrderTableSup> orderTableList = orderManagementSystemClient.getOrderDetailsForSupReport(supId);
            List<OrderSup> orderList = new ArrayList<>();
            for (OrderTableSup orderTableSup : orderTableList) {
                OrderSup orderSup = new OrderSup();
                orderSup.setOrderId(orderTableSup.getOrderId());
                orderSup.setCustId(orderTableSup.getCustId());
                orderSup.setOrderResponseItems(orderManagementSystemClient.getOrderItemDetails(orderTableSup.getOrderId()));
                orderSup.setDate(orderTableSup.getOrderDate());
                orderSup.setTotalPrice(orderTableSup.getTotalPrice());
                orderSup.setStatus(orderTableSup.getOrderStatus());
                orderList.add(orderSup);
            }
            supplierReport.setOrderDetails(orderList);
            supplierReport.setTotalAmountEarned(orderList.stream().mapToDouble(OrderSup::getTotalPrice).sum());
        } else {
            throw new CustomException(OrderManagementSystemConstant.SUPPLIER_DOESNOT_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        return new ResponseEntity<>(supplierReport, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<OrderResponse> getOrderUpdateDetails(OrderRequest orderRequest, int orderId) throws Exception {
        OrderResponse orderResponse = new OrderResponse();
        if (orderManagementSystemClient.checkOrderIdExist(orderId) != OrderManagementSystemConstant.CONSTANT_ZERO) {
            //validate order inputs
            validationUtility.validateOrderInput(orderRequest);
            HashMap<Integer, Integer> mapPrice = new HashMap<Integer, Integer>();
            List<OrderResponseItem> orderResponseItemList = new ArrayList<>();
            double totalPrice = 0.0;
            //gets current price only if stock exist and mapped with productId
            for (OrderRequestItem orderRequestItem : orderRequest.getOrderRequestItemList()) {
                mapPrice.put(orderRequestItem.getProdId(), orderManagementSystemClient.getProductPrice(orderRequest.getSupId(), orderRequestItem.getProdId(), orderRequestItem.getQuantity()));
            }
            String orderStatus = orderManagementSystemClient.fetchOrderStatus(orderId);
            if (orderStatus.equals(OrderManagementSystemConstant.PENDING)) {
                if (orderManagementSystemClient.UpdateOrderId(orderRequest, orderId) == OrderManagementSystemConstant.CONSTANT_ONE) {
                    //sets order response
                    orderResponse.setOrderId(orderId);
                    orderResponse.setOrderDate(orderManagementUtility.getCurrentDate());
                    for (OrderRequestItem orderRequestItem : orderRequest.getOrderRequestItemList()) {
                        int orderItem = orderManagementSystemClient.updateOrderItems(orderId, orderRequestItem, mapPrice, orderRequest.getSupId());
                        if (orderItem != 0) {
                            OrderResponseItem orderResponseItem = orderManagementUtility.setResponseItem(orderRequestItem, mapPrice, orderResponse);
                            orderResponseItemList.add(orderResponseItem);
                        }
                    }
                    orderResponse.setOrderResponseItemList(orderResponseItemList);
                    for (OrderResponseItem orderResponseItem : orderResponseItemList) {
                        totalPrice = totalPrice + orderResponseItem.getTotalPrice();
                    }
                    orderResponse.setSubTotal(totalPrice);
                    orderResponse.setTaxAmount(totalPrice * OrderManagementSystemConstant.CONSTANT_POINT_3);
                    orderResponse.setTotal(orderResponse.getSubTotal() + orderResponse.getTaxAmount());
                    //inserting total price value in ORDER_DETAILS table
                    orderManagementSystemClient.insertTotalPrice(orderResponse, orderId);

                }
            } else {
                throw new CustomException(OrderManagementSystemConstant.ORDER_CANNOT_BE_UPDATED_NOW, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
            }
        }
        else {
            throw new CustomException(OrderManagementSystemConstant.ORDER_ID_DOESNOT_EXISTS, OrderManagementSystemConstant.CONSTANT_FOUR_HUNDRED);
        }
        return new ResponseEntity<>(orderResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Messages> approveOrder(int orderId, boolean status, int custId) throws Exception {
        Messages messages = new Messages();
        String orderStatus = orderManagementSystemClient.fetchOrderStatus(orderId);
        if (orderStatus.equals(OrderManagementSystemConstant.PENDING)) {
            if (status) {
                orderManagementSystemClient.approveOrder(orderId, true, custId);
                messages.setStatus(OrderManagementSystemConstant.APPROVED);
                messages.setMessage(OrderManagementSystemConstant.ORDER_APPROVED);
            } else {
                orderManagementSystemClient.approveOrder(orderId, false, custId);
                messages.setStatus(OrderManagementSystemConstant.REJECTED);
                messages.setMessage(OrderManagementSystemConstant.ORDER_REJECTED);
            }
        } else if (orderStatus.equals(OrderManagementSystemConstant.APPROVED)) {
            messages.setStatus(OrderManagementSystemConstant.FAILED);
            messages.setMessage(OrderManagementSystemConstant.ALREADY_APPROVED);

        } else if (orderStatus.equals(OrderManagementSystemConstant.REJECTED)) {
            messages.setStatus(OrderManagementSystemConstant.FAILED);
            messages.setMessage(OrderManagementSystemConstant.ALREADY_REJECTED);
        }
        return new ResponseEntity<>(messages, HttpStatus.OK);
    }
}
