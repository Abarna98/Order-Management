package org.order.management.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@Data
public class UpdateStock implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private int supplierId;

    @JsonProperty
    private String supplierName;

    @JsonProperty
    List<ProductDetailsUpdate> productDetailsList = new ArrayList<>();
}
