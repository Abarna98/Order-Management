package org.order.management.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@Data
public class OrderResponse implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private int orderId;

    @JsonProperty
    private String orderDate;

    @JsonProperty
    private List<OrderResponseItem> orderResponseItemList=new ArrayList<>();

    @JsonProperty
    private double subTotal;

    @JsonProperty
    private double taxAmount;

    @JsonProperty
    private double discountAmount;

    @JsonProperty
    private double total;
}
