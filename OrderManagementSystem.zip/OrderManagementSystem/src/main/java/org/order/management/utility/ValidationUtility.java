package org.order.management.utility;

import ch.qos.logback.core.util.StringUtil;
import org.order.management.model.*;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

@Component
public class ValidationUtility {

    public void validateCustomerInput(CustomerRequest customerRequest, CustomerResponse customerResponse) throws Exception {
        if (customerRequest == null ||
                StringUtil.isNullOrEmpty(customerRequest.getName())
                || StringUtil.isNullOrEmpty(customerRequest.getPhoneNumber())) {
            throw new CustomException("Input parameter is missing", 400);
        } else {
            if (customerRequest.getPhoneNumber().length() != 10) {
                throw new CustomException("Invalid phone number", 400);
            }
        }
    }

    public void validateSupplierInput(Supplier supplier, SupplierResponse supplierResponse) throws Exception {
        if (supplier == null || StringUtil.isNullOrEmpty(supplier.getAddress()) ||
                StringUtil.isNullOrEmpty(supplier.getName())
                || StringUtil.isNullOrEmpty(supplier.getPhoneNumber())
                || StringUtil.isNullOrEmpty(supplier.getGst())) {
            throw new CustomException("Input parameter is missing", 400);
        } else {
            if (supplier.getGst().length() != 15) {
                throw new CustomException("Invalid gst", 400);
            } else if (supplier.getPhoneNumber().length() != 10) {
                throw new CustomException("Invalid phone number", 400);
            }
        }
    }


    public void validateInsertStockInput(InsertStock insertStock) throws Exception {
        if (insertStock == null || StringUtil.isNullOrEmpty(String.valueOf(insertStock.getSupplierId())) ||
                StringUtil.isNullOrEmpty(insertStock.getSupplierName()) || ObjectUtils.isEmpty(insertStock.getProductDetailsList())) {
            throw new CustomException("Input parameter is missing", 400);
        } else {
            for (ProductDetails productDetails : insertStock.getProductDetailsList()) {
                if (StringUtil.isNullOrEmpty(productDetails.getProductName()) || productDetails.getPrice() == 0) {
                    throw new CustomException("Input parameter is missing", 400);
                }

            }
        }
    }

    public void validateUpdateStockInput(UpdateStock updateStock) throws Exception {
        if (updateStock == null || StringUtil.isNullOrEmpty(String.valueOf(updateStock.getSupplierId())) ||
                StringUtil.isNullOrEmpty(updateStock.getSupplierName()) || ObjectUtils.isEmpty(updateStock.getProductDetailsList())) {
            throw new CustomException("Invalid phone number", 400);
        } else {
            for (ProductDetailsUpdate productDetailsUpdate : updateStock.getProductDetailsList()) {
                if (StringUtil.isNullOrEmpty(productDetailsUpdate.getProductName()) || productDetailsUpdate.getProductId() == 0 || productDetailsUpdate.getPrice() == 0) {
                    throw new CustomException("Input parameter is missing", 400);
                }
            }
        }
    }


    public void validateOrderInput(OrderRequest orderRequest) {
        if (orderRequest == null || orderRequest.getCustId() == 0 || orderRequest.getSupId() == 0  || orderRequest.getOrderRequestItemList().isEmpty()) {
            throw new CustomException("Input parameter is missing", 400);
        }
        else{
            for (OrderRequestItem orderRequestItem: orderRequest.getOrderRequestItemList()) {
                if(orderRequestItem.getProdId()==0)
                {
                    throw new CustomException("Input parameter is missing", 400);
                }
            }
        }

    }
}
