package org.order.management.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
public class CustomerReport implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private int custId;

    @JsonProperty
    private String phoneNumber;

    @JsonProperty
    private int totalNoOfOrders;

    @JsonProperty
    private int pendingOrders;

    @JsonProperty
    private int completedOrders;

    @JsonProperty
    private int cancelledOrders;

    @JsonProperty
    private int approvedOrders;

    @JsonProperty
    private List<Order> ordersList=new ArrayList<>();

    @JsonProperty
    private double totalPurchasedAmount;
}
