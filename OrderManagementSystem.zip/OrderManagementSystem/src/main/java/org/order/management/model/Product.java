package org.order.management.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Data
@Getter
@Setter
public class Product implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private int prodId;

    @JsonProperty
    private int soldCount;

    @JsonProperty
    private double amountEarned;

    @JsonProperty
    private int inStockCount;
}
