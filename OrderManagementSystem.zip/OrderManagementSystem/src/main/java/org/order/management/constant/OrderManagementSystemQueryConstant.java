package org.order.management.constant;

import org.springframework.stereotype.Component;

@Component
public class OrderManagementSystemQueryConstant {

    public static final String CUST_INSERT = "INSERT into CUSTOMER_DETAILS(CUST_NAME,CUST_ADDRESS,CUST_PHONE_NUMBER,STATUS,CREATED_DATE,CREATED_BY,UPDATED_DATE,UPDATED_BY)"
            + "values(?,?,?,?,?,?,?,?)";

    public static final String SUP_INSERT = "INSERT into SUPPLIER_DETAILS(SUP_NAME,GST_NO,SUP_ADDRESS,SUP_PHONE_NUMBER,STATUS,CREATED_DATE,CREATED_BY,UPDATED_DATE,UPDATED_BY)"
            + "values(?,?,?,?,?,?,?,?,?)";

    public static final String FETCH_CUST_ID ="SELECT * FROM CUSTOMER_DETAILS ORDER BY CUST_ID DESC LIMIT 1";

    public static final String FETCH_ORDER_ID ="SELECT * FROM ORDER_DETAILS ORDER BY ORDER_ID DESC LIMIT 1";

    public static final String FETCH_SUP_ID ="SELECT * FROM SUPPLIER_DETAILS ORDER BY SUP_ID DESC LIMIT 1";

    public static final String CUSTOMER_EXIST="select count(*) from CUSTOMER_DETAILS where CUST_PHONE_NUMBER=";

    public static final String CHECK_CUSTOMER_ID_EXIST="select count(*) from CUSTOMER_DETAILS where CUST_ID=";

    public static final String SUPPLIER_EXIST="select count(*) from SUPPLIER_DETAILS where GST_NO=";

    public static final String SUPPLIER_ID_EXIST="select count(*) from SUPPLIER_DETAILS where SUP_ID=";

    public static final String ORDER_ID_EXIST="select count(*) from ORDER_DETAILS where ORDER_ID=";

    public static final String INSERT_STOCK="INSERT into PRODUCT_DETAILS(SUP_ID,PROD_NAME,PRICE,CURRENT_PRICE,IN_STOCK,CREATED_DATE,CREATED_BY,UPDATED_DATE,UPDATED_BY) values(?,?,?,?,?,?,?,?,?)";

    public static final String UPDATE_STOCK="UPDATE PRODUCT_DETAILS SET PRICE = ?, CURRENT_PRICE = ?, IN_STOCK= ?,UPDATED_DATE= ?,UPDATED_BY= ? WHERE PROD_ID = ? ";

    public static final String FETCH_PROD_ID ="SELECT * FROM PRODUCT_DETAILS ORDER BY PROD_ID DESC LIMIT 1";

    public static final String CHECK_PRODUCT_EXIST="select count(*) from PRODUCT_DETAILS where PROD_ID=";

    public static final String AND_OPERATION=" AND SUP_ID=";

    public static final String AND_IN_STOCK =" AND IN_STOCK >= ";

    public static final String GET_PRICE="select CURRENT_PRICE from PRODUCT_DETAILS where PROD_ID=";

    public static final String GET_PRODUCT_PRICE="select CURRENT_PRICE from PRODUCT_DETAILS where PROD_ID=";

    public static final String GENERATE_ORDER_ID = "INSERT into ORDER_DETAILS(CUST_ID,SUP_ID,ORDER_STATUS,CREATED_DATE,CREATED_BY,UPDATED_DATE,UPDATED_BY)"
            + "values(?,?,?,?,?,?,?)";

    public static final String UPDATE_ORDER_ID = "UPDATE ORDER_DETAILS SET CUST_ID = ?, SUP_ID= ?, ORDER_STATUS =?, UPDATED_DATE=?, UPDATED_BY=? WHERE Order_ID = ?";

    public static final String INSERT_ORDER_ITEM = "INSERT into ORDER_ITEMS(ORDER_ID,PROD_ID,SUP_ID,QUANTITY,PRICE,TOTAL_PRICE,CREATED_DATE,CREATED_BY,UPDATED_DATE,UPDATED_BY)"
            + "values(?,?,?,?,?,?,?,?,?,?)";

    public static final String UPDATE_ORDER_ITEM = "UPDATE ORDER_ITEMS SET PROD_ID=?,SUP_ID=?,QUANTITY=?,PRICE=?,TOTAL_PRICE=?,UPDATED_DATE=?,UPDATED_BY=? WHERE ORDER_ID=? ";

    public static final String INSERT_TOTAL_PRICE = "UPDATE ORDER_DETAILS SET SUB_TOTAL= ?,TAX= ?,DISCOUNT= ?,TOTAL_PRICE = ? WHERE ORDER_ID = ?" ;

    public static final String DELETE_ORDER_ITEM =  "UPDATE ORDER_DETAILS SET ORDER_STATUS = ?  WHERE ORDER_ID = ?";

    public static final String FETCH_ORDER_STATUS = "SELECT ORDER_STATUS FROM ORDER_DETAILS WHERE ORDER_ID = ";

    public static final String FETCH_CUST_STATUS = "SELECT STATUS FROM CUSTOMER_DETAILS WHERE CUST_ID = ";

    public static final String FETCH_SUP_STATUS = "SELECT STATUS FROM SUPPLIER_DETAILS WHERE SUP_ID = ";

    public static final String UPDATE_CANCEL_STATUS = "UPDATE ORDER_DETAILS SET ORDER_STATUS = ? WHERE ORDER_ID = ?" ;

    public static final String UPDATE_CUSTOMER_STATUS = "UPDATE CUSTOMER_DETAILS SET STATUS = ? WHERE CUST_ID = ?" ;

    public static final String UPDATE_SUPPLIER_STATUS = "UPDATE SUPPLIER_DETAILS SET STATUS = ? WHERE SUP_ID = ?" ;

    public static final String FETCH_CUST_PHONE_NUMBER = "SELECT CUST_PHONE_NUMBER FROM CUSTOMER_DETAILS WHERE CUST_ID = ";

    public static final String RETR_ORDER_TABLE ="SELECT * FROM ORDER_DETAILS WHERE CUST_ID = ";

    public static final String RETR_ORDER_TABLE_SUP ="SELECT * FROM ORDER_DETAILS WHERE SUP_ID = ";

    public static final String RETR_ORDER_ITEM_TABLE ="SELECT * FROM ORDER_ITEMS WHERE ORDER_ID = ";

    public static final String FETCH_GST_NUMBER = "SELECT GST_NO FROM SUPPLIER_DETAILS WHERE SUP_ID = ";

    public static final String RETR_PROD_ID ="SELECT PROD_ID, IN_STOCK FROM PRODUCT_DETAILS  WHERE SUP_ID = ";

    public static final String RETR_PRODUCT_TABLE ="SELECT PROD_ID, QUANTITY, TOTAL_PRICE FROM ORDER_ITEMS WHERE PROD_ID = ";

    public static final String UPDATE_ORDER_STATUS = "UPDATE ORDER_DETAILS SET ORDER_STATUS = ?, UPDATED_DATE=?, UPDATED_BY=? WHERE ORDER_ID = ?";

    public static final String GET_ITEM_QUANTITY ="SELECT PROD_ID, QUANTITY FROM ORDER_ITEMS WHERE ORDER_ID = ";

    public static final String UPDATE_IN_STOCK="UPDATE PRODUCT_DETAILS SET IN_STOCK = IN_STOCK-?,UPDATED_DATE= ?,UPDATED_BY= ? WHERE PROD_ID = ? ";

    public static final String UPDATE_IN_STOCK_FOR_CANCEL="UPDATE PRODUCT_DETAILS SET IN_STOCK = IN_STOCK+?,UPDATED_DATE= ?,UPDATED_BY= ? WHERE PROD_ID = ? ";
}
