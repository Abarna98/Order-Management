package org.order.management.utility;

import org.order.management.constant.OrderManagementSystemConstant;
import org.order.management.model.*;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;

@Component
public class OrderManagementUtility {
    public void setCustomerResponse(int id, CustomerResponse customerResponse) {
        customerResponse.setCustomerId(id);
        customerResponse.setMessage(OrderManagementSystemConstant.CUST_SUCCESS_RESPONSE);
    }

    public void getSupplierResponse(int id, SupplierResponse supplierResponse) {

        supplierResponse.setSupplierId(id);
        supplierResponse.setMessage(OrderManagementSystemConstant.SUP_SUCCESS_RESPONSE);

    }

    public String getCurrentDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(OrderManagementSystemConstant.DATE_FORMAT);
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }

    public void setStockResponse(List<String> productIds, StockResponse stockResponse, String message) {
        stockResponse.setProductId(productIds);
        stockResponse.setMessage(message);
    }

    public OrderResponseItem setResponseItem(OrderRequestItem orderRequestItem, HashMap<Integer, Integer> mapPrice, OrderResponse orderResponse) {
        OrderResponseItem orderResponseItem = new OrderResponseItem();
        orderResponseItem.setProductId(orderRequestItem.getProdId());
        orderResponseItem.setQuantity(orderRequestItem.getQuantity());
        orderResponseItem.setPrice(mapPrice.get(orderRequestItem.getProdId()));
        int price = orderRequestItem.getQuantity() * mapPrice.get(orderRequestItem.getProdId());
        orderResponseItem.setTotalPrice(price);
        return orderResponseItem;
    }
}
