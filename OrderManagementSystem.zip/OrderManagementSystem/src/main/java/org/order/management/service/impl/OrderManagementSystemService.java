package org.order.management.service.impl;

import org.order.management.model.*;
import org.springframework.http.ResponseEntity;

public interface OrderManagementSystemService {
    public ResponseEntity<CustomerResponse> getCustomerDetails(CustomerRequest customerRequest) throws Exception;

    public ResponseEntity<SupplierResponse> getSupplierDetails(Supplier supplier) throws Exception;

    public ResponseEntity<StockResponse> insertStockDetails(InsertStock insertStock) throws Exception;

    public ResponseEntity<StockResponse> updateStockDetails(UpdateStock updateStock) throws Exception;

    public ResponseEntity<OrderResponse> getOrderDetails(OrderRequest orderRequest) throws Exception;

    ResponseEntity<Messages> cancelOrder(int orderId) throws Exception;

    ResponseEntity<Messages> removeCustomerDetails(int custId) throws Exception;

    ResponseEntity<Messages> removeSupplierDetails(int supId) throws Exception;

    ResponseEntity<CustomerReport> getCustomerReport(int custId) throws Exception;

    ResponseEntity<SupplierReport> getSupplierReport(int supId) throws Exception;

    ResponseEntity<OrderResponse> getOrderUpdateDetails(OrderRequest orderRequest, int orderId) throws Exception;

    ResponseEntity<Messages> approveOrder(int orderId, boolean status, int custId) throws Exception;
}
