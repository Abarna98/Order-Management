package org.order.management.controller;

import jakarta.annotation.Resource;
import org.order.management.model.*;
import org.order.management.service.impl.OrderManagementSystemService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrderManagementSystemController {
    @Resource
    OrderManagementSystemService orderManagementSystemService;


    @PostMapping("/api/add/customer-details")
    public ResponseEntity<CustomerResponse> getCustomerDetails(@RequestBody CustomerRequest customerRequest) throws Exception {
        return orderManagementSystemService.getCustomerDetails(customerRequest);
    }

    @PatchMapping("/api/remove/customer-details")
    public ResponseEntity<Messages> removeCustomerDetails(@RequestParam int custId) throws Exception {
        return orderManagementSystemService.removeCustomerDetails(custId);
    }


    @PostMapping("/api/add/supplier-details")
    public ResponseEntity<SupplierResponse> getSupplierDetails(@RequestBody Supplier supplier) throws Exception {
        return orderManagementSystemService.getSupplierDetails(supplier);
    }

    @PatchMapping("/api/remove/supplier-details")
    public ResponseEntity<Messages> removeSupplierDetails(@RequestParam int supId) throws Exception {
        return orderManagementSystemService.removeSupplierDetails(supId);
    }

    @PostMapping("/api/supplier/stock-insert")
    public ResponseEntity<StockResponse> insertStockDetails(@RequestBody InsertStock insertStock) throws Exception {
        return orderManagementSystemService.insertStockDetails(insertStock);
    }

    @PostMapping("/api/supplier/stock-update")
    public ResponseEntity<StockResponse> updateStockDetails(@RequestBody UpdateStock updateStock) throws Exception {
        return orderManagementSystemService.updateStockDetails(updateStock);
    }

    @PostMapping("/api/order-create")
    public ResponseEntity<OrderResponse> getOrderDetails(@RequestBody OrderRequest orderRequest) throws Exception {
        return orderManagementSystemService.getOrderDetails(orderRequest);
    }

    @PostMapping("/api/order-update")
    public ResponseEntity<OrderResponse> getOrderUpdateDetails(@RequestParam int orderId,@RequestBody OrderRequest orderRequest) throws Exception {
        return orderManagementSystemService.getOrderUpdateDetails(orderRequest,orderId);
    }

    @GetMapping("/api/order-cancel")
    public ResponseEntity<Messages> getOrderDetails(@RequestParam int orderId) throws Exception {
        return orderManagementSystemService.cancelOrder(orderId);
    }

    @GetMapping("/api/customer-report")
    public ResponseEntity<CustomerReport> getCustomerReport(@RequestParam int custId) throws Exception {
        return orderManagementSystemService.getCustomerReport(custId);
    }

    @GetMapping("/api/supplier-report")
    public ResponseEntity<SupplierReport> getSupplierReport(@RequestParam int supId) throws Exception {
        return orderManagementSystemService.getSupplierReport(supId);
    }

    @PatchMapping("/api/approve-order")
    public ResponseEntity<Messages> removeSupplierDetails(@RequestParam int orderId, @RequestParam boolean status, @RequestParam int custId) throws Exception {
        return orderManagementSystemService.approveOrder(orderId,status,custId);
    }
}
