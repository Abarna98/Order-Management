package org.order.management.client;

import jakarta.annotation.Resource;
import org.jetbrains.annotations.NotNull;
import org.order.management.constant.OrderManagementSystemConstant;
import org.order.management.constant.OrderManagementSystemQueryConstant;
import org.order.management.model.*;
import org.order.management.utility.OrderManagementUtility;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Component
public class OrderManagementSystemClient {

    @Resource
    OrderManagementUtility orderManagementUtility;


    public int checkCustomerExist(@NotNull CustomerRequest customerRequest) throws Exception {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        Connection con = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement stmt = con.createStatement();
        String sql = OrderManagementSystemQueryConstant.CUSTOMER_EXIST + customerRequest.getPhoneNumber();
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        return rs.getInt(1);
    }

    public int checkCustomerIdExist(int custId) throws Exception {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        Connection con = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement stmt = con.createStatement();
        String sql = OrderManagementSystemQueryConstant.CHECK_CUSTOMER_ID_EXIST + custId;
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        return rs.getInt(1);
    }


    public int checkSupplierExist(@NotNull Supplier supplier) throws Exception {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        Connection con = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement stmt = con.createStatement();
        String sql = OrderManagementSystemQueryConstant.SUPPLIER_EXIST + supplier.getGst();
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        return rs.getInt(1);
    }

    public int checkSupplierIdExist(int supId) throws Exception {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        Connection con = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement stmt = con.createStatement();
        String sql = OrderManagementSystemQueryConstant.SUPPLIER_ID_EXIST + supId;
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        return rs.getInt(1);
    }

    public int checkOrderIdExist(int orderId) throws Exception {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        Connection con = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement stmt = con.createStatement();
        String sql = OrderManagementSystemQueryConstant.ORDER_ID_EXIST + orderId;
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        return rs.getInt(1);
    }


    public int setCustomerDetails(@NotNull CustomerRequest customerRequest) throws Exception {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement statement = connection.createStatement();
        String sql = OrderManagementSystemQueryConstant.CUST_INSERT;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setString(1, customerRequest.getName());
        preparedStmt.setString(2, customerRequest.getAddress());
        preparedStmt.setString(3, customerRequest.getPhoneNumber());
        preparedStmt.setString(4, OrderManagementSystemConstant.ACTIVE);
        preparedStmt.setDate(5, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(6, customerRequest.getName());
        preparedStmt.setDate(7, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(8, customerRequest.getName());
        return preparedStmt.executeUpdate();
    }

    public int setSupplierDetails(@NotNull Supplier supplier) throws Exception {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement statement = connection.createStatement();
        String sql = OrderManagementSystemQueryConstant.SUP_INSERT;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setString(1, supplier.getName());
        preparedStmt.setString(2, supplier.getGst());
        preparedStmt.setString(3, supplier.getAddress());
        preparedStmt.setString(4, supplier.getPhoneNumber());
        preparedStmt.setString(5, OrderManagementSystemConstant.ACTIVE);
        preparedStmt.setDate(6, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(7, supplier.getName());
        preparedStmt.setDate(8, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(9, supplier.getName());
        return preparedStmt.executeUpdate();
    }

    public int getCustomerId() throws SQLException {
        int custId = 0;
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_CUST_ID);
        ) {
            while (rs.next()) {
                custId = rs.getInt(OrderManagementSystemConstant.CUST_ID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return custId;
    }

    public int getSupplierId() throws SQLException {
        int supId = 0;
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_SUP_ID);
        ) {
            while (rs.next()) {
                supId = rs.getInt(OrderManagementSystemConstant.SUP_ID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return supId;
    }

    public int insertStockDetails(ProductDetails productDetails, @NotNull InsertStock insertStock) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement statement = connection.createStatement();
        String sql = OrderManagementSystemQueryConstant.INSERT_STOCK;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setInt(1, insertStock.getSupplierId());
        preparedStmt.setString(2, productDetails.getProductName());
        preparedStmt.setDouble(3, 0);
        preparedStmt.setDouble(4, productDetails.getPrice());
        preparedStmt.setInt(5, productDetails.getInStock());
        preparedStmt.setDate(6, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(7, insertStock.getSupplierName());
        preparedStmt.setDate(8, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(9, insertStock.getSupplierName());
        return preparedStmt.executeUpdate();
    }

    public int updateStockDetails(ProductDetailsUpdate productDetails, @NotNull UpdateStock updateStock) throws Exception {
        int price = getPrice(productDetails, updateStock.getSupplierId());
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement statement = connection.createStatement();
        String sql = OrderManagementSystemQueryConstant.UPDATE_STOCK;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setInt(1, price);
        preparedStmt.setInt(2, productDetails.getPrice());
        preparedStmt.setInt(3, productDetails.getInStock());
        preparedStmt.setDate(4, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(5, updateStock.getSupplierName());
        preparedStmt.setInt(6, productDetails.getProductId());
        return preparedStmt.executeUpdate();
    }

    public String getProduct() throws SQLException {
        String prod = null;
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_PROD_ID);
        ) {
            while (rs.next()) {
                prod = String.valueOf(rs.getInt(OrderManagementSystemConstant.PROD_ID)) + " : " + rs.getString(OrderManagementSystemConstant.PROD_NAME);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prod;
    }


    public int checkProductExist(ProductDetailsUpdate productDetails, int supplierId) throws Exception {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        Connection con = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement stmt = con.createStatement();
        String sql = OrderManagementSystemQueryConstant.CHECK_PRODUCT_EXIST + productDetails.getProductId() + OrderManagementSystemQueryConstant.AND_OPERATION + supplierId;
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        return rs.getInt(1);
    }

    public int getPrice(ProductDetailsUpdate productDetails, int supplierId) throws Exception {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        Connection con = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement stmt = con.createStatement();
        String sql = OrderManagementSystemQueryConstant.GET_PRICE + productDetails.getProductId() + OrderManagementSystemQueryConstant.AND_OPERATION + supplierId;
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        return rs.getInt(1);
    }

    public int getProductPrice(int supplierId, int productId, int quantity) throws Exception {
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        Connection con = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement stmt = con.createStatement();
        String sql = OrderManagementSystemQueryConstant.GET_PRODUCT_PRICE + productId + OrderManagementSystemQueryConstant.AND_OPERATION + supplierId + OrderManagementSystemQueryConstant.AND_IN_STOCK + quantity;
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        return rs.getInt(1);
    }

    public int generateOrderId(@NotNull OrderRequest orderRequest) throws Exception {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement statement = connection.createStatement();
        String sql = OrderManagementSystemQueryConstant.GENERATE_ORDER_ID;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setInt(1, orderRequest.getCustId());
        preparedStmt.setInt(2, orderRequest.getSupId());
        preparedStmt.setString(3, OrderManagementSystemConstant.PENDING);
        preparedStmt.setDate(4, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(5, OrderManagementSystemConstant.ADMIN);
        preparedStmt.setDate(6, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(7, OrderManagementSystemConstant.ADMIN);
        return preparedStmt.executeUpdate();
    }

    public int getSingleOrderId() throws SQLException {
        int orderId = 0;
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_ORDER_ID);
        ) {
            while (rs.next()) {
                orderId = rs.getInt(OrderManagementSystemConstant.ORDER_ID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return orderId;
    }

    public int insertOrderItems(int orderId, OrderRequestItem orderRequestItem, HashMap<Integer, Integer> mapPrice, int supId) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        String sql = OrderManagementSystemQueryConstant.INSERT_ORDER_ITEM;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setInt(1, orderId);
        preparedStmt.setInt(2, orderRequestItem.getProdId());
        preparedStmt.setInt(3, supId);
        preparedStmt.setInt(4, orderRequestItem.getQuantity());
        preparedStmt.setDouble(5, mapPrice.get(orderRequestItem.getProdId()));
        preparedStmt.setDouble(6, orderRequestItem.getQuantity() * mapPrice.get(orderRequestItem.getProdId()));
        preparedStmt.setDate(7, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(8, OrderManagementSystemConstant.ADMIN);
        preparedStmt.setDate(9, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(10, OrderManagementSystemConstant.ADMIN);
        return preparedStmt.executeUpdate();
    }

    public void insertTotalPrice(OrderResponse orderResponse, int orderId) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        String sql = OrderManagementSystemQueryConstant.INSERT_TOTAL_PRICE;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setDouble(1, orderResponse.getSubTotal());
        preparedStmt.setDouble(2, orderResponse.getTaxAmount());
        preparedStmt.setDouble(3, orderResponse.getDiscountAmount());
        preparedStmt.setDouble(4, orderResponse.getTotal());
        preparedStmt.setInt(5, orderId);
        preparedStmt.executeUpdate();

    }

    public int cancelOrder(int orderId) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        PreparedStatement preparedStmt = connection.prepareStatement(OrderManagementSystemQueryConstant.DELETE_ORDER_ITEM);
        preparedStmt.setString(1, OrderManagementSystemConstant.CANCELLED);
        preparedStmt.setInt(2, orderId);
        return preparedStmt.executeUpdate();
    }

    public int updateCancelStatus(int orderId) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        PreparedStatement preparedStmt = connection.prepareStatement(OrderManagementSystemQueryConstant.UPDATE_CANCEL_STATUS);
        preparedStmt.setString(1, OrderManagementSystemConstant.CANCELLED);
        preparedStmt.setInt(2, orderId);
        return preparedStmt.executeUpdate();
    }

    public int updateCustDetail(int custId) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        PreparedStatement preparedStmt = connection.prepareStatement(OrderManagementSystemQueryConstant.UPDATE_CUSTOMER_STATUS);
        preparedStmt.setString(1, OrderManagementSystemConstant.IN_ACTIVE);
        preparedStmt.setInt(2, custId);
        return preparedStmt.executeUpdate();
    }

    public int updateSupDetail(int supId) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        PreparedStatement preparedStmt = connection.prepareStatement(OrderManagementSystemQueryConstant.UPDATE_SUPPLIER_STATUS);
        preparedStmt.setString(1, OrderManagementSystemConstant.IN_ACTIVE);
        preparedStmt.setInt(2, supId);
        return preparedStmt.executeUpdate();
    }

    public String fetchOrderStatus(int orderId) throws SQLException {
        String orderStatus = "";
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_ORDER_STATUS + orderId);
        ) {
            while (rs.next()) {
                orderStatus = rs.getString(OrderManagementSystemConstant.ORDER_STATUS);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderStatus;
    }

    public String fetchCustomerStatus(int custId) throws SQLException {
        String custStatus = "";
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_CUST_STATUS + custId);
        ) {
            while (rs.next()) {
                custStatus = rs.getString(OrderManagementSystemConstant.STATUS);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return custStatus;
    }

    public String fetchSupplierStatus(int supId) throws SQLException {
        String custStatus = "";
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_SUP_STATUS + supId);
        ) {
            while (rs.next()) {
                custStatus = rs.getString(OrderManagementSystemConstant.STATUS);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return custStatus;
    }

    public String getPhoneNumber(int custId) {
        String custPhoneNumber = "";
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_CUST_PHONE_NUMBER + custId);
        ) {
            while (rs.next()) {
                custPhoneNumber = rs.getString(OrderManagementSystemConstant.CUST_PHONE_NUMBER);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return custPhoneNumber;
    }

    public List<OrderTable> getOrderDetailsForCustReport(int custId) {
        List<OrderTable> orderTableList = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.RETR_ORDER_TABLE + custId);
        ) {
            while (rs.next()) {
                OrderTable orderTable = new OrderTable();
                orderTable.setOrderId(rs.getInt("ORDER_ID"));
                orderTable.setSupId(rs.getInt("SUP_ID"));
                orderTable.setOrderStatus(rs.getString("ORDER_STATUS"));
                orderTable.setOrderDate(rs.getDate("CREATED_DATE").toString());
                orderTable.setTotalPrice(rs.getDouble("TOTAL_PRICE"));
                orderTableList.add(orderTable);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderTableList;
    }

    public List<OrderResponseItem> getOrderItemDetails(int orderId) {
        List<OrderResponseItem> orderResponseItemList = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.RETR_ORDER_ITEM_TABLE + orderId);
        ) {
            while (rs.next()) {
                OrderResponseItem orderResponseItem = new OrderResponseItem();
                orderResponseItem.setProductId(rs.getInt("PROD_ID"));
                orderResponseItem.setQuantity(rs.getInt("QUANTITY"));
                orderResponseItem.setPrice(rs.getDouble("PRICE"));
                orderResponseItem.setTotalPrice(rs.getDouble("TOTAL_PRICE"));
                orderResponseItemList.add(orderResponseItem);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderResponseItemList;
    }

    public String getGSTNumber(int supId) {
        String gSTNo = "";
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.FETCH_GST_NUMBER + supId);
        ) {
            while (rs.next()) {
                gSTNo = rs.getString(OrderManagementSystemConstant.GST_NO);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return gSTNo;
    }

    public List<Product> getProductDetails(int supId, Map<Integer, Integer> prodId_quantity) {
        List<Product> productList = new ArrayList<>();
        for (Integer prodId : prodId_quantity.keySet()) {
            Product product = new Product();
            int quantity = 0;
            double totalPrice = 0.0;
            try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.RETR_PRODUCT_TABLE + prodId + " AND SUP_ID = " + supId);
            ) {
                while (rs.next()) {

                    quantity = quantity + rs.getInt("QUANTITY");
                    totalPrice = totalPrice + rs.getDouble("TOTAL_PRICE");
                }
                product.setSoldCount(quantity);
                product.setAmountEarned(totalPrice);
                product.setProdId(prodId);
                product.setInStockCount(prodId_quantity.get(prodId));
                productList.add(product);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return productList;
    }

    public Map<Integer, Integer> getProdId(int supId) {
        Map<Integer, Integer> prodId_quantity = new HashMap<>();
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.RETR_PROD_ID + supId);
        ) {
            while (rs.next()) {
                prodId_quantity.put(rs.getInt("PROD_ID"), rs.getInt("IN_STOCK"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }


        return prodId_quantity;
    }

    public List<OrderTableSup> getOrderDetailsForSupReport(int supId) {
        List<OrderTableSup> orderTableList = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.RETR_ORDER_TABLE_SUP + supId);
        ) {
            while (rs.next()) {
                OrderTableSup orderTableSup = new OrderTableSup();
                orderTableSup.setOrderId(rs.getInt("ORDER_ID"));
                orderTableSup.setCustId(rs.getInt("CUST_ID"));
                orderTableSup.setOrderStatus(rs.getString("ORDER_STATUS"));
                orderTableSup.setOrderDate(rs.getDate("CREATED_DATE").toString());
                orderTableSup.setTotalPrice(rs.getDouble("TOTAL_PRICE"));
                orderTableList.add(orderTableSup);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderTableList;
    }

    public int UpdateOrderId(@NotNull OrderRequest orderRequest, int orderId) throws Exception {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        Statement statement = connection.createStatement();
        String sql = OrderManagementSystemQueryConstant.UPDATE_ORDER_ID;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setInt(1, orderRequest.getCustId());
        preparedStmt.setInt(2, orderRequest.getSupId());
        preparedStmt.setString(3, OrderManagementSystemConstant.PENDING);
        preparedStmt.setDate(4, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(5, OrderManagementSystemConstant.ADMIN);
        preparedStmt.setInt(6, orderId);
        return preparedStmt.executeUpdate();
    }

    public int updateOrderItems(int orderId, OrderRequestItem orderRequestItem, HashMap<Integer, Integer> mapPrice, int supId) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        String sql = OrderManagementSystemQueryConstant.UPDATE_ORDER_ITEM;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setInt(1, orderRequestItem.getProdId());
        preparedStmt.setInt(2, supId);
        preparedStmt.setInt(3, orderRequestItem.getQuantity());
        preparedStmt.setDouble(4, mapPrice.get(orderRequestItem.getProdId()));
        preparedStmt.setDouble(5, orderRequestItem.getQuantity() * mapPrice.get(orderRequestItem.getProdId()));
        preparedStmt.setDate(6, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(7, OrderManagementSystemConstant.ADMIN);
        preparedStmt.setInt(8, orderId);
        return preparedStmt.executeUpdate();
    }

    public void approveOrder(int orderId, boolean status, int custId) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        String sql = OrderManagementSystemQueryConstant.UPDATE_ORDER_STATUS;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        if (status) {
            preparedStmt.setString(1, "APPROVED");
            Map<Integer, Integer> item_quantity = getQuantity(orderId);
            for (Integer prodId : item_quantity.keySet()) {
                updateStockQuantity(prodId, item_quantity);
            }


        } else {
            preparedStmt.setString(1, "REJECTED");
        }
        preparedStmt.setDate(2, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(3, String.valueOf(custId));
        preparedStmt.setInt(4, orderId);
        preparedStmt.executeUpdate();
    }

    public void updateStockQuantity(int prodId, Map<Integer, Integer> item_quantity) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        String sql = OrderManagementSystemQueryConstant.UPDATE_IN_STOCK;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setInt(1, item_quantity.get(prodId));
        preparedStmt.setDate(2, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(3, OrderManagementSystemConstant.ADMIN);
        preparedStmt.setInt(4, prodId);
        preparedStmt.executeUpdate();
    }

    public void updateStockQuantityForCancel(int prodId, Map<Integer, Integer> item_quantity) throws SQLException {
        Connection connection = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
        String sql = OrderManagementSystemQueryConstant.UPDATE_IN_STOCK_FOR_CANCEL;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setInt(1, item_quantity.get(prodId));
        preparedStmt.setDate(2, Date.valueOf(orderManagementUtility.getCurrentDate()));
        preparedStmt.setString(3, OrderManagementSystemConstant.ADMIN);
        preparedStmt.setInt(4, prodId);
        preparedStmt.executeUpdate();
    }

    public Map<Integer, Integer> getQuantity(int orderId) {
        Map<Integer, Integer> item_quantity = new HashMap<>();
        try (Connection conn = DriverManager.getConnection(OrderManagementSystemConstant.DB_URL, OrderManagementSystemConstant.USER_NAME, OrderManagementSystemConstant.PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(OrderManagementSystemQueryConstant.GET_ITEM_QUANTITY + orderId);
        ) {
            while (rs.next()) {

                item_quantity.put(rs.getInt("PROD_ID"), rs.getInt("QUANTITY"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return item_quantity;

    }
}
