package com.service.impl;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.model.LoginRequest;
import com.model.LoginResponse;
import com.model.SignupRequest;
import com.model.SignupResponse;



@Service
public class TtaServiceImpl implements TtaService {


    @Override
    public ResponseEntity<LoginResponse> login(LoginRequest loginRequest) throws Exception {
    	LoginResponse loginResponse = new LoginResponse();
    	loginResponse.setMessage("Success");
       
        return new ResponseEntity<>(loginResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SignupResponse> signup(SignupRequest signupRequest) throws Exception {
    	SignupResponse signupResponse = new SignupResponse();
    	signupResponse.setTtaId("TTA-001");
       
        return new ResponseEntity<>(signupResponse, HttpStatus.OK);
    }

}
