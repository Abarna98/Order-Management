package com.service.impl;

import com.model.*;
import org.springframework.http.ResponseEntity;

public interface TtaService {
	
    public ResponseEntity<LoginResponse> login(LoginRequest login) throws Exception;
    
    public ResponseEntity<SignupResponse> signup(SignupRequest signupRequest) throws Exception;

}
