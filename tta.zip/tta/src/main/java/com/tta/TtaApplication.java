package com.tta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(scanBasePackages = {"com.controller", "com.service.impl"})
public class TtaApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        SpringApplication.run(TtaApplication.class, args);

	}

}
