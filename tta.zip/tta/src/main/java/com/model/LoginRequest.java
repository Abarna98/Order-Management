package com.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;


@Data
@Getter
@Setter
public class LoginRequest implements Serializable {


    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private String ttaId;

    @JsonProperty
    private String password;

}
