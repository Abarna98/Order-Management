package com.utility;

import org.springframework.stereotype.Component;

@Component
public class ValidationUtility {

   
}
