package com.controller;



import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.LoginRequest;
import com.model.LoginResponse;
import com.model.SignupRequest;
import com.model.SignupResponse;
import com.service.impl.TtaService;

import jakarta.annotation.Resource;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class TtaController {
    @Resource
    TtaService ttaService;
 
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest loginRequest) throws Exception {
        return ttaService.login(loginRequest);
    }

    @PostMapping("/signup")
    public ResponseEntity<SignupResponse> signup(@RequestBody SignupRequest signupRequest) throws Exception{
    	return ttaService.signup(signupRequest);
    }
}
