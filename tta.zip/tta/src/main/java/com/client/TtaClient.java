package com.client;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.stereotype.Component;

import com.constant.TtaConstant;
import com.constant.TtaQueryConstant;
import com.model.SignupRequest;



@Component
public class TtaClient {




    public int insertStudentDetails(SignupRequest signupRequest) throws SQLException {
        Connection connection = DriverManager.getConnection(TtaConstant.DB_URL, TtaConstant.USER_NAME, TtaConstant.PASSWORD);
        String sql = TtaQueryConstant.INSERT_STUDENT;
        PreparedStatement preparedStmt = connection.prepareStatement(sql);
        preparedStmt.setString(1, signupRequest.getName());
        preparedStmt.setString(2, signupRequest.getRollNo());
        preparedStmt.setString(3, signupRequest.getEmailId());
        preparedStmt.setString(4, signupRequest.getPassword());
        preparedStmt.setString(5, signupRequest.getPhoneNumber());
        preparedStmt.setString(6, signupRequest.getCollegeCode());
        preparedStmt.setString(7, signupRequest.getYop());
        preparedStmt.setString(8, signupRequest.getDegree());
        preparedStmt.setString(10,signupRequest.getDepartment());
        preparedStmt.setString(11,signupRequest.getBatchNo());
        return preparedStmt.executeUpdate();
    }

   
}
